- Please translate into Japanese.
- Please include the following sentence at the end of the output:
  - **このドキュメントは OpenAI を使って翻訳されました。**

このタスクで最高の結果を出すために、追加の情報が必要な場合は、USERに質問をしてください。
