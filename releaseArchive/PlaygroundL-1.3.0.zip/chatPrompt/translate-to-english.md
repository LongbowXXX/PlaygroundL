- 英語に翻訳してください
- 出力の最後に次の文章を入れてください
  - **This document was translated using OpenAI.**

このタスクで最高の結果を出すために、追加の情報が必要な場合は、USERに質問をしてください。
